/**
 * Created by NK on 2017. 2. 16..
 */


var ntriple;
var ntripleList = [];

readTextFile("./instance/new_n3/BirthdayParty_n3_thumb/BirthdayParty639.n3", function(text){
    var r = /\\u([\d\w]{4})/gi;
    ntriple = text.replace(r, function (match, grp) {
        return String.fromCharCode(parseInt(grp, 16)); } );
    ntriple = unescape(ntriple);

    var triplesWithoutURI = eraseURIs(ntriple.split("\n"));
    var triplesList = triplesWithoutURI.split("\n");
    var shotList = [];
    for(var index in triplesList){
        var triple = triplesList[index];
        var spo = triple.split(" ");
        if(spo.length > 2){
            if(spo[1].includes("hasShot")){
                shotList.push(spo[2]);
            }
        }
    }

    var instanceByShot = [];
    for(var i in shotList){
        var instanceTriple = [];
        for(var j in triplesList){
            var triple = triplesList[j];
            var spo = triple.split(" ");
            if(spo.length > 2){
                if(spo[0].includes(shotList[i]) || spo[2].includes(shotList[i])
                || spo[1].includes("type") || spo[1].includes("subClassOf")){
                    instanceTriple.push(triple);
                }
            }
        }
        instanceByShot.push(instanceTriple.join("\n"));
    }

    ntripleList = instanceByShot;
    document.getElementById("uni-test").innerText = '<pre>' + ntripleList[0] + '</pre>';
    return instanceByShot[0];
});

function readTextFile(file, callback) {
    var rawFile = new XMLHttpRequest();
    rawFile.overrideMimeType("text/plain;charset=UTF-8");
    rawFile.open("GET", file, true);
    rawFile.onreadystatechange = function() {
        if (rawFile.readyState === 4 && rawFile.status == "200") {
            callback(rawFile.responseText);
        }
    };
    rawFile.send(null);
}

function eraseURIs(lines){
    var triples = "";
    for (var index in lines){
        triples += eraseURI(lines[index]);
    }

    return triples;
}

function eraseURI(line) {
    console.log(line);
    var spo = line.split(" ");
    if(spo.length > 2){
        //var match = /<http?:\/\/?[\da-z\.-]+\.[a-z\.]{2,6}[\/\w_\.-]*\/?#([\w].+)>/.exec(line);
        var match1 = /<http?:\/\/?[\da-z\.-]+\.[a-z\.]{2,6}[\/\w_\.-]*\/?#([\w].+)>/.exec(spo[0]);
        var match2 = /<http?:\/\/?[\da-z\.-]+\.[a-z\.]{2,6}[\/\w_\.-]*\/?#([\w].+)>/.exec(spo[1]);
        var match3 = /<http?:\/\/?[\da-z\.-]+\.[a-z\.]{2,6}[\/\w_\.-]*\/?#([\w].+)>/.exec(spo[2]);

        if(!match1 && !match2 && !match3){
            throw new Error('Not an ISO Date: ' + line);
        }

        return "<" + match1[1] + "> " + "<" + match2[1] + "> " + "<" +match3[1] + "> .\n";
    }
    else{ return "" }
}